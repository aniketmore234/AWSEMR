class StockPipeline(object):
    def process_item(self, item, spider):
        return item
