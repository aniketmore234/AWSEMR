# coding: utf-8
from scrapy.spider import BaseSpider
from scrapy.selector import Selector
from crawler.items import StockItem
from lxml import html
import requests
from time import sleep
import json
import argparse
from collections import OrderedDict
#from time import sleep


class StockSpider(BaseSpider):
	name = 'stock'
	allowed_domains = ['finance.yahoo.com']

	start_urls = open("urls.txt").read().splitlines()
	def parse(self, response):
		self.log('URL: %s' % response.url)
		ticker = response.url.split("=")[1]
		print ticker
		try:
			hxs = Selector(response)
			item = StockItem()
			item['CompanyName'] = hxs.select('//*[@id="quote-header-info"]/div[2]/div[1]/div[1]/h1/text()').extract()
			item['Price'] = hxs.select('//*[@id="quote-header-info"]/div[3]/div[1]/div/span[1]/text()').extract()
			item['PrevClose'] = hxs.select('//*[@id="quote-summary"]/div[1]/table/tbody/tr[1]/td[2]/span/text()').extract()
			item['Open'] = hxs.select('//*[@id="quote-summary"]/div[1]/table/tbody/tr[2]/td[2]/span/text()').extract()
			item['DayRange'] = hxs.select('//*[@id="quote-summary"]/div[1]/table/tbody/tr[5]/td[2]/text()').extract()
			item['YearRange'] = hxs.select('//*[@id="quote-summary"]/div[1]/table/tbody/tr[6]/td[2]/text()').extract()
			item['Volume'] = hxs.select('//*[@id="quote-summary"]/div[1]/table/tbody/tr[7]/td[2]/span/text()').extract()
			item['MarketCap'] = hxs.select('//*[@id="quote-summary"]/div[2]/table/tbody/tr[1]/td[2]/text()').extract()
			item['Beta'] = hxs.select('//*[@id="quote-summary"]/div[2]/table/tbody/tr[2]/td[2]/span/text()').extract()
			item['PERatioTTM'] = hxs.select('//*[@id="quote-summary"]/div[2]/table/tbody/tr[3]/td[2]/span/text()').extract()
			item['EPSTTM'] = hxs.select('//*[@id="quote-summary"]/div[2]/table/tbody/tr[4]/td[2]/span/text()').extract()
			item['ForwardDivYield'] = hxs.select('//*[@id="quote-summary"]/div[2]/table/tbody/tr[6]/td[2]/text()').extract()
			item['OneYearTragetEstimate'] = hxs.select('//*[@id="quote-summary"]/div[2]/table/tbody/tr[8]/td[2]/span/text()').extract()
			#item['Error']= "False"
			#with open("filter-urls.txt", 'a') as outfile:
			#	outfile.write(ticker+"\n")
			return item
		except:
			print "Error"
		#return item

